#!/bin/sh

#  colleration legth - temperature.py
#  
#
#  Created by Tung Nguyen on 4/20/19.
#

from isingmodelgraphics import isingmodel, Col, size, Temp
import numpy as np
import pylab as py

#Create the average graph
avg_r = []

#Finding the correlation graph
#Here I change the temperature distances from 0.5 to 1.5, from 1.5 to 2.5, and from 2.5 to 3.5
for T in np.arange(2.5,3.5,0.05):
    r = []
    for interation in range(1,10*size):
        data = isingmodel(T,size)
        collab = Col(data)
        #Find r so that c = 1/e
        for i in range(0,len(collab)):
            # Finding the corrabolation data nearest to the 1/e
            if  ((i+1)<len(collab)) and (collab[i] >= 1/np.e) and (collab[i+1] <= 1/np.e):
                r.append(collab[i])
                break
    avg_r.append(np.mean(r))

#Extracting the datas from each interval
file = open("list.txt", "w")
for index in range(len(Temp)):
    file.write(str(Temp[index]) + " " + str(avg_r[index]) + "\n")
file.close()
py.plot(Temp,avg_r,"r.")
py.show()
