#!/bin/sh

#  problem 8.26.sh
#  Thermal Physics
#
#  Created by Tung Nguyen on 4/20/19.
#Program Ising

import random as rd
import numpy as np
import pylab as py
import matplotlib.pyplot as plt
from matplotlib import colors

size = 20 # The size of the lattice
T = 2.00 # Temperature


def isingmodel(T):
    # Initial array of zero inputs
    s = np.zeros((size, size))

    #Generate a random array of grids
    for i in range(0,size):
        for j in range(0,size):
            if rd.uniform(0,1) <.5:
                s[i,j] = 1
            else:
                s[i,j] = -1


    #Define the potential different og flipping a dipole:
    def deltaU(i,j):
        if i == 0:
            top = s[size-1,j]
        else:
            top = s[i-1,j]
        if i == size-1:
            bottom = s[0,j]
        else:
            bottom = s[i+1,j]
        if j == 0:
            left = s[i,size-1]
        else:
            left = s[i,j-1]
        if j == size-1:
            right = s[i,0]
        else:
            right = s[i,j+1]
        Ediff = 2*s[i,j]*(top+bottom+left+right)
        # Put colors inside the grid:
        return Ediff

    for interation in range(1,100*size**2):
        i = int(rd.uniform(0,1)*size)
        j = int(rd.uniform(0,1)*size)
        Ediff = deltaU(i,j)
        if Ediff <= 0:
            s[i,j]= -s[i,j]
        elif rd.uniform(0,1) < np.exp(-Ediff/T):
            s[i,j]= -s[i,j]
    return s

# Define the correlative function calculating over a data
def Col(data):
    index = np.zeros(size)
    index += 0.01
    sum = np.zeros(size)
    spin = np.zeros(size)
    for p in range(1,100*size**2):
        i = int(rd.uniform(0,1)*size)
        j = int(rd.uniform(0,1)*size)
        k = int(rd.uniform(0,1)*size)
        m = int(rd.uniform(0,1)*size)
        r1 = np.sqrt((i - k)**2 + (j - m)**2)
        r2 = np.sqrt((i - k + size)**2 + (j - m)**2)
        r3 = np.sqrt((i - k)**2 + (j - m + size)**2)
        r4 = np.sqrt((i - k - size)**2 + (j - m)**2)
        r5 = np.sqrt((i - k)**2 + (j - m - size)**2)
        
        r6 = np.sqrt((i - k + size)**2 + (j - m + size)**2)
        r7 = np.sqrt((i - k - size)**2 + (j - m - size)**2)
        r8 = np.sqrt((i - k - size)**2 + (j - m + size)**2)
        r9 = np.sqrt((i - k + size)**2 + (j - m - size)**2)
        
        rad = int(np.min((r1, r2, r3, r4, r5,r6,r7,r8,r9)))
        if (rad>0):
            index[rad] += 1
            sum[rad] += data[i,j]*data[k,m]
            spin[rad] += data[i,j]

#Create a plot database for the collaboration function
    collaborative = []
    for rad in range(0,size):
        average = sum[rad]/index[rad] - (spin[rad]/index[rad])**2;
        collaborative.append(average)
    return collaborative

data = isingmodel(T)

distance = []
for r in range(0,int(size)):
    distance.append(r)

# create discrete colormap
cmap = colors.ListedColormap(['white', 'black'])
bounds = [-1,0,1]
norm = colors.BoundaryNorm(bounds, cmap.N)
fig, ax = plt.subplots()
ax.imshow(data, cmap=cmap , norm=norm)

# draw gridlines
ax.grid(which='major', axis='both', linestyle='-', color='k', linewidth=2)
plt.show()

#Showing the collaborative function:
py.plot(distance, Col(data),"r.")
py.show()


